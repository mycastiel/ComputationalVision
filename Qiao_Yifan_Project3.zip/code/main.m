% Read spheres
sphere2 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq1/sphere2.pgm');
sphere3 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq1/sphere3.pgm');
sphere4 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq1/sphere4.pgm');
sphere5 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq1/sphere5.pgm');
sphere6 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq1/sphere6.pgm');
spheres = cat(3,sphere2,sphere3,sphere4,sphere5,sphere6);

% Read centers
center1 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq2/center1.jpg');
center2 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq2/center2.jpg');
center3 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq2/center3.jpg');
center4 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq2/center4.jpg');
center5 = imread('/Users/qiaoyifan/Desktop/code/proj3_seq2/center5.jpg');
centers = cat(3,center1,center2,center3,center4,center5);

%% OF FOR SPHERES
boxSize = 2;
figure; hold on;
for c=0:5:160
    for r=15:5:185
        centralPixel = [c;r];
        A = fitCubicRegion(spheres,centralPixel,boxSize);
        v=KMethod(A,2); 
        quiver(r,c,v(2),v(1),'b','MaxHeadSize',8)
    end
end

% % OF FOR CENTER
boxSize = 16;
figure; hold on;
for c=335:20:535
    for r=300:20:500
        centralPixel = [c;r];
        A = fitCubicRegion(centers,centralPixel,boxSize);
        v=KMethod(A,12); 
        quiver(r,c,v(2),v(1),'b','MaxHeadSize',8)
    end
end
