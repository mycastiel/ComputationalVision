clc;
clear;
close;

%read the images
Image1=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_01.png');
Image2=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_02.png');
Image3=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_03.png');
Image4=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_04.png');
Image5=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_05.png');
Image6=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_06.png');
Image7=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_07.png');
Image8=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_08.png');
Image9=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_09.png');
Image10=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_10.png');
Image11=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_11.png');
Image12=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_12.png');
Image13=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_13.png');
Image14=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_14.png');
Image15=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_15.png');
Image16=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_16.png');
Image17=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_17.png');
Image18=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_18.png');
Image19=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_19.png');
Image20=imread('/Users/qiaoyifan/Desktop/frog/Objects/Image_20.png');


%convert the image values into double
Double_img1 = double(Image1);
Double_img2 = double(Image2);
Double_img3 = double(Image3);
Double_img4 = double(Image4);
Double_img5 = double(Image5);
Double_img6 = double(Image6);
Double_img7 = double(Image7);
Double_img8 = double(Image8);
Double_img9 = double(Image9);
Double_img10 = double(Image10);
Double_img11 = double(Image11);
Double_img12 = double(Image12);
Double_img13 = double(Image13);
Double_img14 = double(Image14);
Double_img15 = double(Image15);
Double_img16 = double(Image16);
Double_img17 = double(Image17);
Double_img18 = double(Image18);
Double_img19 = double(Image19);
Double_img20 = double(Image20);

%Normalize the images so that the intensity values are between 0-1
Normalize_Image1 =mat2gray(Double_img1)./255;
Normalize_Image2 =mat2gray(Double_img2)./255;
Normalize_Image3 =mat2gray(Double_img3)./255;
Normalize_Image4 =mat2gray(Double_img4)./255;
Normalize_Image5 =mat2gray(Double_img5)./255;
Normalize_Image6 =mat2gray(Double_img6)./255;
Normalize_Image7 =mat2gray(Double_img7)./255;
Normalize_Image8 =mat2gray(Double_img8)./255;
Normalize_Image9 =mat2gray(Double_img9)./255;
Normalize_Image10 =mat2gray(Double_img10)./255;
Normalize_Image11 =mat2gray(Double_img11)./255;
Normalize_Image12 =mat2gray(Double_img12)./255;
Normalize_Image13 =mat2gray(Double_img13)./255;
Normalize_Image14 =mat2gray(Double_img14)./255;
Normalize_Image15 =mat2gray(Double_img15)./255;
Normalize_Image16 =mat2gray(Double_img16)./255;
Normalize_Image17 =mat2gray(Double_img17)./255;
Normalize_Image18 =mat2gray(Double_img18)./255;
Normalize_Image19 =mat2gray(Double_img19)./255;
Normalize_Image20 =mat2gray(Double_img20)./255;


%Input the Source vectors corresponding to each image in matrix
v1 = [-0.3522186690487052;  -0.2680594879526620  -0.3242043885433767];
v2 = [-0.3290559124929677;  -0.2992438629992032;  -0.14633971863718255];
v3 = [-0.1421015485975874  -0.1578601220453086  -0.138569349993093];
v4 = [-0.1330428982309168   0.1716963898225248   0.2180341631984904 ];
v5 = [0.2036864738021666   0.2055318671400338   0.1717376274147299];
v6 = [0.3366268887432585   0.3756778808387846   0.4026985378037113];
v7 = [0.4280722304327883   0.4379577505608870 0.5349984544673531];
v8 = [0.3981202212629192   0.1523087840301342  -0.0383447478019401];
v9 = [-0.1907604895297728   0.4133115972374394   0.2936162237564596];
v10 = [-0.0306302553029559;  -0.2464874433896574;  -0.3795038499944304];
v11 = [0.4034001331211117   0.2433180823193381  -0.0183830429817098];
v12 = [-0.2832386470580964  -0.4017903243347228   0.5939423768226527];
v13 = [0.5056295601911101   0.2974126751346439   0.0992713675350475];
v14 = [-0.0458513279204876 0.7679314180909009   0.8772937936290904];
v15 = [0.9336453013626091   0.9435316034820592   0.9349136570249017];
v16 = [0.8987536983724890   0.9453024188232906   0.9869863065554233];
v17 = [0.9591884462886958   0.9155743634843228   0.8987706505665286];
v18 = [0.9451229626322566   0.9788635676746643   0.9367670577057193];
v19 = [0.8994835866212110   0.7306947316008868   0.7766626537367587];
v20 = [0.8656671348272428;   0.8982757711972528;   0.8978255200491774];
v1 = v1/norm(v1,2);
v2 = v2/norm(v2,2);
v3 = v3/norm(v3,2);
v4 = v4/norm(v4,2);
v5 = v5/norm(v5,2);
v6 = v6/norm(v6,2);
v7 = v7/norm(v7,2);
v8 = v8/norm(v8,2);
v9 = v9/norm(v9,2);
v10 = v10/norm(v10,2);
v11 = v11/norm(v11,2);
v12 = v12/norm(v12,2);
v13 = v13/norm(v13,2);
v14 = v14/norm(v14,2);
v15 = v15/norm(v15,2);
v16 = v16/norm(v16,2);
v17 = v17/norm(v17,2);
v18 = v18/norm(v18,2);
v19 = v19/norm(v19,2);
v20 = v20/norm(v20,2);

%stack the input vectors of the images in another vector
V = [v2'; v10';  v20'];

%calculate the number of rows and columns of the images. It is the same
%value for all images.
rows = size(Normalize_Image1,1);
cols = size(Normalize_Image1,2);
 
%initialize the I(c,r) vector where I(c,r)= albedo(c,r).N(c,r)
%initialzie the p , q and the normal Vector N
I = zeros(rows,cols,3);
albedo = zeros(rows,cols);
p = zeros(rows,cols);
q = zeros(rows,cols);
N = zeros(rows,cols, 3);

%running through the entire image we calculate the I(c,r) by solving the
%linear system of equations
for r = 1:rows;
for c = 1:cols;
   i = [ Normalize_Image2(r,c); Normalize_Image10(r,c); Normalize_Image20(r,c)];
   Ivector = diag(i);
   B = Ivector * i;
   A = Ivector * V;
   rank_of_B=rank(A);
   if rank_of_B<3
       continue;
   end   
        X = A\B;
        %disp(size(X))
        I(r,c,:) = X;   
        albedo(r,c) = norm(X);
        N(r,c,:) = X/norm(X);
        p(r,c) = N(r,c,1)/N(r,c,3);
        q(r,c) = N(r,c,2)/N(r,c,3);
   
end
end

%Show the Normal Vector;
figure(5);
imshow(N);

%To caculate the albedo of the given image whose values should be
%between 0-1
maximumAlbedo = max(max(albedo) );
if(maximumAlbedo > 0)
    albedo = albedo/maximumAlbedo;
end

%To calculate Depth Map
depth=zeros(rows,cols);
for i = 2:size(Double_img1,1)
for j = 2:size(Double_img1,2)
depth(i,j) = depth(i-1,j-1)+q(i,j)+p(i,j);
end
end

%Albedo Figure
figure(1);
imagesc(albedo);
figure(2)
imagesc(albedo);
colormap(gray);

%Depth gray image
figure(3);
surfl(-depth);
colormap(gray);
grid off;
shading interp

figure(4);
surfl(-depth);
colormap(gray);
title('Mesh grid ');
grid off;
shading interp

[ X, Y ] = meshgrid( 1:cols, 1:rows );
figure;
surf( X, Y, -depth, 'EdgeColor', 'none' );
camlight left;
title('Depth Map');
lighting phong

%Constructing the Needle Map which shows the normals pointing on the
%surface
figure
spacing = 1;
[X Y] = meshgrid(1:spacing:cols, 1:spacing:rows);
quiver3(X,Y,-depth,N(:,:,1),N(:,:,2),N(:,:,3))
hold on;
title('Depth Map');
hold off

Z = DepthFromGradient(-p, -q);
% Visualize depth map.
figure;
Z(isnan(N(:,:,1)) | isnan(N(:,:,2)) | isnan(N(:,:,3))) = NaN;
surf(Z, 'EdgeColor', 'None', 'FaceColor', [0.5 0.5 0.5]);
axis equal; camlight;




