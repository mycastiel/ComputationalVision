% Read spheres
sphere1 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/10.pgm');
sphere2 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/11.pgm');
sphere3 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/12.pgm');
sphere4 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/13.pgm');
sphere5 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/14.pgm');
sphere6 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/15.pgm');
sphere7 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/16.pgm');
sphere8 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/17.pgm');
sphere9 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/18.pgm');
sphere10 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/19.pgm');
sphere11 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/20.pgm');
sphere12 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/21.pgm');
sphere13 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/22.pgm');
sphere14 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/23.pgm');
sphere15 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/24.pgm');
sphere16 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/25.pgm');
sphere17 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/26.pgm');
sphere18 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/27.pgm');
sphere19 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/28.pgm');
sphere20 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/29.pgm');
sphere21 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/30.pgm');
sphere22 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/31.pgm');
sphere23 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/32.pgm');
sphere24 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/33.pgm');
sphere25 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/34.pgm');
sphere26 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/35.pgm');
sphere27 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/36.pgm');
sphere28 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/37.pgm');
sphere29 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/38.pgm');
sphere30 = imread('/Users/qiaoyifan/Desktop/proj4_img_seq/39.pgm');

spheres = cat(3,sphere1,sphere2,sphere3,sphere4,sphere5,sphere6,sphere7,sphere8,sphere9,sphere10,sphere11,sphere12,sphere13,sphere14,sphere15,sphere16,sphere17,sphere18,sphere19,sphere20,sphere21,sphere22,sphere23,sphere24,sphere25,sphere26,sphere27,sphere28,sphere29,sphere30);


%% OF FOR SPHERES
boxSize = 2;
figure; hold on;
for c=15:5:235
    for r=15:5:315
        centralPixel = [c;r];
        A = fitCubicRegion(spheres,centralPixel,boxSize);
        v=lucasKMethod(A,2); 
        quiver(r,c,v(2),v(1),'b','MaxHeadSize',8)
    end
end

% % OF FOR GRID
% boxSize = 16;
% figure; hold on;
% for c=335:20:535
%     for r=275:20:475
%         centralPixel = [c;r];
%         A = fitCubicRegion(grids,centralPixel,boxSize);
%         v=lucasKMethod(A,12); 
%         quiver(r,c,v(2),v(1),'b','MaxHeadSize',8)
%     end
% end
% 
% % OF FOR PEOPLE
% boxSize = 2;
% figure; hold on;
% for c=10:2:230
%     for r=10:2:310
%         centralPixel = [c;r];
%         A = fitCubicRegion(peoples,centralPixel,boxSize);
%         v=lucasKMethod(A,1);
%         if norm(v) > 0
%             quiver(r,c,v(2),v(1),'b','MaxHeadSize',8)
%         end
%     end
% end