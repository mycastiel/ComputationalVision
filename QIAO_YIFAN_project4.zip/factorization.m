clc
clear all;
close all;
disp("tt")
%% Factorization Method
% Read sequence of photos
H{1}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/10.pgm');
H{2}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/11.pgm');
H{3}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/12.pgm');
H{4}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/13.pgm');
H{5}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/14.pgm');
H{6}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/15.pgm');
H{7}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/16.pgm');
H{8}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/17.pgm');
H{9}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/18.pgm');
H{10}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/19.pgm');
H{11}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/20.pgm');
H{12}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/21.pgm');
H{13}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/22.pgm');
H{14}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/23.pgm');
H{15}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/24.pgm');
H{16}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/25.pgm');
H{17}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/26.pgm');
H{18}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/27.pgm');
H{19}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/28.pgm');
H{20}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/29.pgm');
H{21}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/30.pgm');
H{22}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/31.pgm');
H{23}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/32.pgm');
H{24}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/33.pgm');
H{25}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/34.pgm');
H{26}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/35.pgm');
H{27}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/36.pgm');
H{28}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/37.pgm');
H{29}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/38.pgm');
H{30}=imread('/Users/qiaoyifan/Desktop/proj4_img_seq/39.pgm');
disp("start");
%Get all the points
for i=1:30
    %figure
    HF{i} = detectHarrisFeatures(H{i});
    pH{i} = HF{i}.selectStrongest(15).Location;
    imshow(H{i}); hold on;
    plot(HF{i}.selectStrongest(15));
end
allPoints=[pH{1,1}];
% Get the points
for i=2:30
    allPoints=[allPoints; pH{1,i}];
end
%allPoints = load('Points.pts');
allX = allPoints(:,1);
allY = allPoints(:,2);
disp(size(allX));
% Measurement Matrix
W = [allX(1:15)';allX(16:30)';allX(31:45)';allX(46:60)';allX(61:75)';allX(76:90)';...
    allX(91:105)';allX(106:120)';allX(121:135)';allX(136:150)';allX(151:165)';allX(166:180)';...
    allX(181:195)';allX(196:210)';allX(211:225)';allX(226:240)';allX(241:255)';allX(256:270)';...
    allX(271:285)';allX(286:300)';allX(301:315)';allX(316:330)';allX(331:345)';allX(346:360)';...
    allX(361:375)';allX(376:390)';allX(391:405)';allX(406:420)';allX(421:435)';...
    allY(1:15)';allY(16:30)';allY(31:45)';allY(46:60)';allY(61:75)';allY(76:90)';...
    allY(91:105)';allY(106:120)';allY(121:135)';allY(136:150)';allY(151:165)';allY(166:180)';...
    allY(181:195)';allY(196:210)';allY(211:225)';allY(226:240)';allY(241:255)';allY(256:270)';...
    allY(271:285)';allY(286:300)';allY(301:315)';allY(316:330)';allY(331:345)';allY(346:360)';...
    allY(361:375)';allY(376:390)';allY(391:405)';allY(406:420)';allY(421:435)'];

disp(size(W));

% Means to normalize around 0
for i=1:10
   meanX{i} = mean(W(i,:)); 
   meanY{i} = mean(W(i+10,:));

   W(i,:) = W(i,:)-meanX{i};
   W(i+10,:) = W(i+10,:)-meanY{i};
end

%Single value decomposition & Fill L
[U D V] = svd(W);
Ucut = [U(:,1) U(:,2) U(:,3)];
Dcut = [D(1,1:3);D(2,1:3);D(3,1:3)];
Vcut = [V(:,1) V(:,2) V(:,3)];

RT = Ucut*Dcut^(0.5);
STemp = Dcut^(0.5)*Vcut';

A = [RT(1,1)*RT(1,1) 2*RT(1,1)*RT(1,2) 2*RT(1,1)*RT(1,3)...
    RT(1,2)*RT(1,2) 2*RT(1,2)*RT(1,3) RT(1,3)*RT(1,3);
    RT(2,1)*RT(2,1) 2*RT(2,1)*RT(2,2) 2*RT(2,1)*RT(2,3)...
    RT(2,2)*RT(2,2) 2*RT(2,2)*RT(2,3) RT(2,3)*RT(2,3);
    RT(3,1)*RT(3,1) 2*RT(3,1)*RT(3,2) 2*RT(3,1)*RT(3,3)...
    RT(3,2)*RT(3,2) 2*RT(3,2)*RT(3,3) RT(3,3)*RT(3,3);
    RT(4,1)*RT(4,1) 2*RT(4,1)*RT(4,2) 2*RT(4,1)*RT(4,3)...
    RT(4,2)*RT(4,2) 2*RT(4,2)*RT(4,3) RT(4,3)*RT(4,3);
    RT(5,1)*RT(5,1) 2*RT(5,1)*RT(5,2) 2*RT(5,1)*RT(5,3)...
    RT(5,2)*RT(5,2) 2*RT(5,2)*RT(5,3) RT(5,3)*RT(5,3);
    RT(6,1)*RT(6,1) 2*RT(6,1)*RT(6,2) 2*RT(6,1)*RT(6,3)...
    RT(6,2)*RT(6,2) 2*RT(6,2)*RT(6,3) RT(6,3)*RT(6,3);
    RT(1,1)*RT(4,1) 2*RT(1,1)*RT(4,2) 2*RT(1,1)*RT(4,3)...
    RT(1,2)*RT(4,2) 2*RT(1,2)*RT(4,3) RT(1,3)*RT(4,3);
    RT(2,1)*RT(5,1) 2*RT(2,1)*RT(5,2) 2*RT(2,1)*RT(5,3)...
    RT(2,2)*RT(5,2) 2*RT(2,2)*RT(5,3) RT(2,3)*RT(5,3);
    RT(3,1)*RT(6,1) 2*RT(3,1)*RT(6,2) 2*RT(3,1)*RT(6,3)...
    RT(3,2)*RT(6,2) 2*RT(3,2)*RT(6,3) RT(3,3)*RT(6,3)];

disp(size(A));

C = [1;1;1;1;1;1;0;0;0;];
LTemp = pinv(A)*C;
L = [LTemp(1) LTemp(2) LTemp(3);
    LTemp(2) LTemp(4) LTemp(5);
    LTemp(3) LTemp(5) LTemp(6)];

%Eigenvalues
[diagL matL] = eig(L);
R = RT*diagL;
S = inv(diagL)*STemp;

%Trying to reconstruct the points

%figure
%imshow(H{1}); hold on;
%plot(allPoints(1:15,1),allPoints(1:15,2),'+r');
figure
plot3(S(1,:),S(2,:),S(3,:),'+b');
axis square, grid on
xlabel('X')
ylabel('Y')
zlabel('Z')